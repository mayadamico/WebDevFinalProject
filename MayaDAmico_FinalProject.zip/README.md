# WebDevFinalProject - Project Overview
Final Project for Intro to Web Dev @ UVM

## Therapy Practice Wesite

This is a website for my mother's therapy practice. I worked on this independently.

**Features**

1. JavaScript Language Switcher
I used this tutorial (and a lot of trial and error): https://www.geeksforgeeks.org/how-to-switch-the-language-of-the-page-using-javascript/

2. Responsive formats
Both pages of the website use @media queries to adjust and modify the format to match whatever size screen a person is viewing it on.

3. Contact Form
The data is stored locally, so it can't actually function for the purpose of a live website. But it does use the concepts learned over this course for the purpose of a demo.


- Maya D'Amico
